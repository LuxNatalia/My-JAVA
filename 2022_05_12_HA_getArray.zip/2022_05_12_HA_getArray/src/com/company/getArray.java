package com.company;

public interface getArray {
    public abstract int[] getNewArray();

}
