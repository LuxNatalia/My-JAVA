package com.company;

public class definedArray implements getArray{
    @Override
    public int[] getNewArray() {
        int [] arr = {10, 20, 30, 40, 50};
        return arr;
    }
}
